﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogicTier;
using System.Data.SqlClient;
using System.Data;

public partial class admin_index : System.Web.UI.Page
{
    clsLogin objlogin = new clsLogin();
    clsUser objuser = new clsUser();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try {
            objlogin.username = txtusername.Text;
            objlogin.password = txtpassword.Text;
            objlogin.IpAddress = GetIPAddress();
            DataTable dt = new DataTable();
            dt = objlogin.Chk_AdminLoginDetails(objlogin);
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["loginflag"].ToString() == "1")
                {
                    //Session["useradmin"] = dt.Rows[0]["username"].ToString();
                    HttpContext.Current.Session["useradmin"] = dt.Rows[0]["username"].ToString();

                    //Response.Redirect("Dashboard.aspx");
                    Random rnd = new Random();
                    string str_otpemail = rnd.Next(100000, 999999).ToString();
                    objuser.OTP = str_otpemail;
                    //objuser.Email = dt.Rows[0]["EmailForOTP"].ToString();
                    objuser.EmailSubject = "Rijent- Login OTP";
                    objuser.EmailBody = @"Dear User OTP is " + str_otpemail;
                    string res = objuser.SendEmailOTPAdminLogin(objuser);
                    if (res == "t")
                    {
                        string popupScript = "toastr.success('Success', 'OTP has been Sent To Your Email.');";
                        ScriptManager.RegisterStartupScript(uplMaster, uplMaster.GetType(), Guid.NewGuid().ToString(), popupScript, true);
                        string popupScript2 = "showModal();";
                        ScriptManager.RegisterStartupScript(uplMaster, uplMaster.GetType(), Guid.NewGuid().ToString(), popupScript2, true);

                        //Session["resetuserid"] = txtusername.Text;
                        Session["adminloginotp"] = str_otpemail;
                        Response.Redirect("AdminOTP.aspx");
                    }
                    else
                    {
                        string popupScript = "toastr.error('Error', 'Unknown Error Occurred');";
                        ScriptManager.RegisterStartupScript(uplMaster, uplMaster.GetType(), Guid.NewGuid().ToString(), popupScript, true);
                    }
                }
                else
                {
                    Message.Show("Invalid Login Details...!!!");
                }
            }
            else
            {
                Message.Show("Invalid Login Details...!!!");
            }
        }
        catch (Exception ep){
            Message.Show("Invalid Lgin Details...!!!");
        }
      
    }
    public string GetIPAddress()
    {
        string ipaddress;
        ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        if (ipaddress == "" || ipaddress == null)
            ipaddress = Request.ServerVariables["REMOTE_ADDR"];
        return ipaddress;
    }

    protected void btnUpdatepassword_Click(object sender, EventArgs e)
    {

    }
}