﻿using BusinessLogicTier;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class admin_UserReport : System.Web.UI.Page
{
    clsAccount objaccount = new clsAccount();
    clsClosing objclosing = new clsClosing();
    clsUser objuser = new clsUser();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["userid"] != null)
            {
                loadtopuptype();
                Session["topentries"] = "50";
                loaduser();
            }
            else
            {
                Response.Redirect("logout.aspx");
            }
        }
    }
    void loadtopuptype()
    {
        objuser.UserId = Session["userid"].ToString();
        ddtopup.Items.Clear();
        DataTable dt = new DataTable();
        dt = objuser.getMyTopup(objuser);
        ddtopup.DataSource = dt;
        ddtopup.DataTextField = "amount2";
        ddtopup.DataValueField = "id";
        ddtopup.DataBind();
        ListItem li = new ListItem("Select Amount", "0");
        ddtopup.Items.Insert(0, li);
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        
        Session["topentries"] = "99999999";
        loaduser();
    }

    void loaduser()
    {
        objaccount.UserId = Session["userid"].ToString();
        if (txtfromdate.Text != "")
        {
            objaccount.FromDate = Message.GetIndianDate(txtfromdate.Text);
        }
        else
        {
            objaccount.FromDate = DateTime.MinValue;
        }
        if (txttodate.Text != "")
        {
            objaccount.ToDate = Message.GetIndianDate(txttodate.Text);
        }
        else
        {
            objaccount.ToDate = DateTime.MinValue;
        }
        objaccount.Id = ddtopup.SelectedValue.ToString();
        objaccount.TopEntries = Session["topentries"].ToString();
        DataTable dt = new DataTable();
        dt = objaccount.getROIDetail2(objaccount);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
  
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      
    }
 
}